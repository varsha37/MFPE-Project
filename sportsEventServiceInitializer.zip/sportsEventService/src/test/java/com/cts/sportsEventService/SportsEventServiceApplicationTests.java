package com.cts.sportsEventService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsEventServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
