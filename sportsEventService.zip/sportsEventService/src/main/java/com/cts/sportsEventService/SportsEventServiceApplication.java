package com.cts.sportsEventService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsEventServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsEventServiceApplication.class, args);
	}

}
